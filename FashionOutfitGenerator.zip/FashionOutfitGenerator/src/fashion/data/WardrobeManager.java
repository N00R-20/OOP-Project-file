package fashion.data;

import fashion.model.ClothingItem;
import fashion.model.ClothingItem.Category;
import fashion.model.ClothingItem.Season;
import fashion.model.ClothingItem.Style;
import fashion.model.Outfit;
import fashion.model.UserProfile;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Central manager for wardrobe items, outfits, and user profile.
 * Uses OOP principles: encapsulation, abstraction.
 */
public class WardrobeManager {

    private static WardrobeManager instance;

    private List<ClothingItem> wardrobe;
    private List<Outfit> savedOutfits;
    private UserProfile userProfile;
    private int idCounter = 1;

    private WardrobeManager() {
        wardrobe = new ArrayList<>();
        savedOutfits = new ArrayList<>();
        userProfile = new UserProfile("fashionista", "Style Queen");
        loadSampleData();
    }

    public static WardrobeManager getInstance() {
        if (instance == null) instance = new WardrobeManager();
        return instance;
    }

    // ── Wardrobe CRUD ────────────────────────────────────────────────────────

    public void addClothingItem(ClothingItem item) { wardrobe.add(item); }

    public void removeClothingItem(String id) {
        wardrobe.removeIf(i -> i.getId().equals(id));
    }

    public ClothingItem findById(String id) {
        return wardrobe.stream().filter(i -> i.getId().equals(id)).findFirst().orElse(null);
    }

    public List<ClothingItem> getAllItems() { return new ArrayList<>(wardrobe); }

    public List<ClothingItem> getByCategory(Category cat) {
        return wardrobe.stream().filter(i -> i.getCategory() == cat).collect(Collectors.toList());
    }

    public List<ClothingItem> getByStyle(Style style) {
        return wardrobe.stream().filter(i -> i.getStyle() == style).collect(Collectors.toList());
    }

    public List<ClothingItem> getBySeason(Season season) {
        return wardrobe.stream()
                .filter(i -> i.getSeason() == season || i.getSeason() == Season.ALL_SEASON)
                .collect(Collectors.toList());
    }

    public List<ClothingItem> getFavoriteItems() {
        return wardrobe.stream().filter(ClothingItem::isFavorite).collect(Collectors.toList());
    }

    public List<ClothingItem> search(String query) {
        String q = query.toLowerCase();
        return wardrobe.stream()
                .filter(i -> i.getName().toLowerCase().contains(q)
                        || i.getColor().toLowerCase().contains(q)
                        || i.getBrand().toLowerCase().contains(q))
                .collect(Collectors.toList());
    }

    // ── Outfit generation ────────────────────────────────────────────────────

    public Outfit generateOutfit(Style style, Season season, String occasion) {
        Random rnd = new Random();
        Outfit outfit = new Outfit(nextId(), generateOutfitName(style), season, style, occasion);

        List<ClothingItem> pool = wardrobe.stream()
                .filter(i -> i.getStyle() == style
                        && (i.getSeason() == season || i.getSeason() == Season.ALL_SEASON))
                .collect(Collectors.toList());

        // pick one from each key category
        Category[] priorities = {Category.TOP, Category.BOTTOM, Category.SHOES,
                Category.OUTERWEAR, Category.ACCESSORIES, Category.BAG};

        for (Category cat : priorities) {
            List<ClothingItem> candidates = pool.stream()
                    .filter(i -> i.getCategory() == cat).collect(Collectors.toList());
            if (!candidates.isEmpty()) {
                outfit.addItem(candidates.get(rnd.nextInt(candidates.size())));
            }
        }

        // if we ended up with almost nothing, relax style filter
        if (outfit.getItems().size() < 2) {
            List<ClothingItem> relaxed = getBySeason(season);
            Collections.shuffle(relaxed);
            for (Category cat : priorities) {
                if (!outfit.hasCategory(cat)) {
                    relaxed.stream().filter(i -> i.getCategory() == cat)
                            .findFirst().ifPresent(outfit::addItem);
                }
            }
        }
        return outfit;
    }

    private String generateOutfitName(Style style) {
        String[] adjectives = {"Chic", "Stunning", "Effortless", "Radiant", "Bold", "Sleek", "Dreamy"};
        Random r = new Random();
        return adjectives[r.nextInt(adjectives.length)] + " " + style + " Look";
    }

    // ── Saved Outfits ────────────────────────────────────────────────────────

    public void saveOutfit(Outfit o) { savedOutfits.add(o); }
    public void removeOutfit(String id) { savedOutfits.removeIf(o -> o.getId().equals(id)); }
    public List<Outfit> getSavedOutfits() { return new ArrayList<>(savedOutfits); }
    public List<Outfit> getFavoriteOutfits() {
        return savedOutfits.stream().filter(Outfit::isFavorite).collect(Collectors.toList());
    }

    // ── User Profile ─────────────────────────────────────────────────────────

    public UserProfile getUserProfile() { return userProfile; }
    public void setUserProfile(UserProfile p) { userProfile = p; }

    // ── Stats ────────────────────────────────────────────────────────────────

    public int getTotalItems() { return wardrobe.size(); }
    public int getTotalOutfits() { return savedOutfits.size(); }

    public Map<String, Integer> getCategoryStats() {
        Map<String, Integer> map = new LinkedHashMap<>();
        for (Category c : Category.values())
            map.put(c.getDisplayName(), (int) wardrobe.stream().filter(i -> i.getCategory() == c).count());
        return map;
    }

    // ── ID helper ────────────────────────────────────────────────────────────

    public String nextId() { return "ID" + (idCounter++); }

    // ── Sample data ──────────────────────────────────────────────────────────

    private void loadSampleData() {
        // TOPS
        addClothingItem(new ClothingItem(nextId(),"Silk Blouse","Zara","Ivory",Category.TOP,Season.ALL_SEASON,Style.ELEGANT,"Lightweight silk blouse with pearl buttons"));
        addClothingItem(new ClothingItem(nextId(),"Graphic Tee","H&M","Black",Category.TOP,Season.SUMMER,Style.CASUAL,"Oversized graphic cotton tee"));
        addClothingItem(new ClothingItem(nextId(),"Cashmere Sweater","Marks & Spencer","Dusty Rose",Category.TOP,Season.WINTER,Style.CASUAL,"Soft cashmere pullover"));
        addClothingItem(new ClothingItem(nextId(),"Crop Tank","Shein","White",Category.TOP,Season.SUMMER,Style.CASUAL,"Basic ribbed crop tank"));
        addClothingItem(new ClothingItem(nextId(),"Oxford Shirt","Ralph Lauren","Light Blue",Category.TOP,Season.ALL_SEASON,Style.FORMAL,"Classic cotton Oxford shirt"));
        addClothingItem(new ClothingItem(nextId(),"Floral Blouse","Mango","Multicolor",Category.TOP,Season.SPRING,Style.BOHEMIAN,"Flowy floral print blouse"));
        addClothingItem(new ClothingItem(nextId(),"Turtleneck","Uniqlo","Charcoal",Category.TOP,Season.WINTER,Style.ELEGANT,"Fine knit turtleneck sweater"));
        addClothingItem(new ClothingItem(nextId(),"Sports Bra","Nike","Coral",Category.TOP,Season.SUMMER,Style.SPORTY,"High-support sports bra"));
        addClothingItem(new ClothingItem(nextId(),"Band Tee","Urban Outfitters","Washed Black",Category.TOP,Season.ALL_SEASON,Style.STREETWEAR,"Vintage-washed band tee"));
        addClothingItem(new ClothingItem(nextId(),"Lace Cami","Zara","Champagne",Category.TOP,Season.SUMMER,Style.ELEGANT,"Delicate lace camisole"));

        // BOTTOMS
        addClothingItem(new ClothingItem(nextId(),"Tailored Trousers","Massimo Dutti","Navy",Category.BOTTOM,Season.ALL_SEASON,Style.FORMAL,"High-waist tailored trousers"));
        addClothingItem(new ClothingItem(nextId(),"Mom Jeans","Levi's","Light Wash",Category.BOTTOM,Season.ALL_SEASON,Style.CASUAL,"High-waist relaxed jeans"));
        addClothingItem(new ClothingItem(nextId(),"Mini Skirt","Topshop","Denim",Category.BOTTOM,Season.SUMMER,Style.CASUAL,"Frayed denim mini skirt"));
        addClothingItem(new ClothingItem(nextId(),"Maxi Skirt","Free People","Terracotta",Category.BOTTOM,Season.SPRING,Style.BOHEMIAN,"Flowy maxi skirt with elastic waist"));
        addClothingItem(new ClothingItem(nextId(),"Pleated Skirt","Mango","Blush",Category.BOTTOM,Season.SPRING,Style.ELEGANT,"Midi pleated satin skirt"));
        addClothingItem(new ClothingItem(nextId(),"Joggers","Adidas","Grey",Category.BOTTOM,Season.ALL_SEASON,Style.SPORTY,"Slim-fit track joggers"));
        addClothingItem(new ClothingItem(nextId(),"Cargo Pants","Carhartt","Olive",Category.BOTTOM,Season.AUTUMN,Style.STREETWEAR,"Baggy cargo pants with pockets"));
        addClothingItem(new ClothingItem(nextId(),"Leather Trousers","Zara","Black",Category.BOTTOM,Season.AUTUMN,Style.ELEGANT,"Faux leather slim trousers"));

        // DRESSES
        addClothingItem(new ClothingItem(nextId(),"Wrap Dress","Diane von Furstenberg","Floral",Category.DRESS,Season.SPRING,Style.ELEGANT,"Classic silk wrap dress"));
        addClothingItem(new ClothingItem(nextId(),"LBD","BCBG","Black",Category.DRESS,Season.ALL_SEASON,Style.ELEGANT,"Little black cocktail dress"));
        addClothingItem(new ClothingItem(nextId(),"Sundress","Anthropologie","Yellow",Category.DRESS,Season.SUMMER,Style.BOHEMIAN,"Tiered cotton sundress"));
        addClothingItem(new ClothingItem(nextId(),"Bodycon Dress","Fashion Nova","Red",Category.DRESS,Season.ALL_SEASON,Style.CASUAL,"Ribbed bodycon midi dress"));
        addClothingItem(new ClothingItem(nextId(),"Shirt Dress","& Other Stories","Stripe",Category.DRESS,Season.SUMMER,Style.CASUAL,"Relaxed stripe shirt dress"));

        // OUTERWEAR
        addClothingItem(new ClothingItem(nextId(),"Trench Coat","Burberry","Camel",Category.OUTERWEAR,Season.AUTUMN,Style.ELEGANT,"Classic double-breasted trench"));
        addClothingItem(new ClothingItem(nextId(),"Denim Jacket","Levi's","Blue",Category.OUTERWEAR,Season.SPRING,Style.CASUAL,"Trucker denim jacket"));
        addClothingItem(new ClothingItem(nextId(),"Puffer Jacket","Canada Goose","Black",Category.OUTERWEAR,Season.WINTER,Style.CASUAL,"Down-filled puffer coat"));
        addClothingItem(new ClothingItem(nextId(),"Blazer","Zara","Cream",Category.OUTERWEAR,Season.ALL_SEASON,Style.FORMAL,"Oversized structured blazer"));
        addClothingItem(new ClothingItem(nextId(),"Leather Jacket","AllSaints","Black",Category.OUTERWEAR,Season.AUTUMN,Style.STREETWEAR,"Moto leather biker jacket"));
        addClothingItem(new ClothingItem(nextId(),"Kimono","Free People","Printed",Category.OUTERWEAR,Season.SPRING,Style.BOHEMIAN,"Floral printed kimono"));

        // SHOES
        addClothingItem(new ClothingItem(nextId(),"Stiletto Heels","Louboutin","Nude",Category.SHOES,Season.ALL_SEASON,Style.ELEGANT,"Classic pointed-toe pumps"));
        addClothingItem(new ClothingItem(nextId(),"White Sneakers","Adidas","White",Category.SHOES,Season.ALL_SEASON,Style.CASUAL,"Stan Smith leather sneakers"));
        addClothingItem(new ClothingItem(nextId(),"Chelsea Boots","Dr. Martens","Black",Category.SHOES,Season.AUTUMN,Style.STREETWEAR,"Classic leather Chelsea boots"));
        addClothingItem(new ClothingItem(nextId(),"Strappy Sandals","Steve Madden","Gold",Category.SHOES,Season.SUMMER,Style.BOHEMIAN,"Strappy heeled sandals"));
        addClothingItem(new ClothingItem(nextId(),"Running Shoes","Nike","Pink",Category.SHOES,Season.ALL_SEASON,Style.SPORTY,"Lightweight running trainers"));
        addClothingItem(new ClothingItem(nextId(),"Loafers","Gucci","Black",Category.SHOES,Season.ALL_SEASON,Style.FORMAL,"Horsebit leather loafers"));
        addClothingItem(new ClothingItem(nextId(),"Platform Boots","Topshop","Brown",Category.SHOES,Season.WINTER,Style.VINTAGE,"Chunky platform ankle boots"));
        addClothingItem(new ClothingItem(nextId(),"Espadrilles","Castaner","Natural",Category.SHOES,Season.SUMMER,Style.CASUAL,"Jute-sole wedge espadrilles"));

        // ACCESSORIES
        addClothingItem(new ClothingItem(nextId(),"Pearl Necklace","Mikimoto","White",Category.ACCESSORIES,Season.ALL_SEASON,Style.ELEGANT,"Classic cultured pearl strand"));
        addClothingItem(new ClothingItem(nextId(),"Silk Scarf","Hermès","Multicolor",Category.ACCESSORIES,Season.ALL_SEASON,Style.ELEGANT,"Printed silk twill scarf"));
        addClothingItem(new ClothingItem(nextId(),"Bucket Hat","New Era","Olive",Category.ACCESSORIES,Season.SUMMER,Style.STREETWEAR,"Canvas bucket hat"));
        addClothingItem(new ClothingItem(nextId(),"Beret","Sandro","Black",Category.ACCESSORIES,Season.AUTUMN,Style.VINTAGE,"Wool felt French beret"));
        addClothingItem(new ClothingItem(nextId(),"Gold Hoops","Mejuri","Gold",Category.ACCESSORIES,Season.ALL_SEASON,Style.CASUAL,"14k gold filled hoop earrings"));
        addClothingItem(new ClothingItem(nextId(),"Sunglasses","Ray-Ban","Tortoise",Category.ACCESSORIES,Season.SUMMER,Style.CASUAL,"Aviator sunglasses"));
        addClothingItem(new ClothingItem(nextId(),"Beaded Bracelet","Pandora","Mixed",Category.ACCESSORIES,Season.ALL_SEASON,Style.BOHEMIAN,"Handmade beaded bracelet set"));

        // BAGS
        addClothingItem(new ClothingItem(nextId(),"Tote Bag","Longchamp","Black",Category.BAG,Season.ALL_SEASON,Style.CASUAL,"Foldable nylon tote"));
        addClothingItem(new ClothingItem(nextId(),"Mini Crossbody","Coach","Tan",Category.BAG,Season.ALL_SEASON,Style.ELEGANT,"Leather mini crossbody bag"));
        addClothingItem(new ClothingItem(nextId(),"Backpack","Fjällräven","Forest Green",Category.BAG,Season.ALL_SEASON,Style.CASUAL,"Kånken canvas backpack"));
        addClothingItem(new ClothingItem(nextId(),"Clutch","Zara","Metallic Silver",Category.BAG,Season.ALL_SEASON,Style.FORMAL,"Satin evening clutch"));
        addClothingItem(new ClothingItem(nextId(),"Belt Bag","Gucci","Brown",Category.BAG,Season.ALL_SEASON,Style.STREETWEAR,"Leather waist belt bag"));
        addClothingItem(new ClothingItem(nextId(),"Woven Bag","Cult Gaia","Natural",Category.BAG,Season.SUMMER,Style.BOHEMIAN,"Bamboo arc bag"));
    }
}
