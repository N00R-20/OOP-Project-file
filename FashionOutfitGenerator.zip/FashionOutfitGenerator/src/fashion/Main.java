package fashion;

import fashion.ui.MainWindow;
import fashion.ui.SplashScreen;
import fashion.util.AppTheme;

import javax.swing.*;

/**
 * Application entry point for Fashion Outfit Generator.
 *
 * OOP Concepts Demonstrated:
 *  - Encapsulation   : private fields + getters/setters in all model classes
 *  - Abstraction     : WardrobeManager hides data access logic
 *  - Inheritance     : custom Swing components extend JPanel, JButton, etc.
 *  - Polymorphism    : ListCellRenderer, custom paintComponent overrides
 *  - Singleton       : WardrobeManager.getInstance()
 *  - Collections     : ArrayList, List, Map throughout
 *  - Enums           : Category, Season, Style, BodyType
 */
public class Main {

    public static void main(String[] args) {
        // Apply system look-and-feel as base, then override with AppTheme
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {}

        AppTheme.applyGlobalDefaults();

        SwingUtilities.invokeLater(() -> {
            SplashScreen splash = new SplashScreen();
            splash.animateAndLaunch(() -> {
                MainWindow window = new MainWindow();
                window.setVisible(true);
            });
        });
    }
}
