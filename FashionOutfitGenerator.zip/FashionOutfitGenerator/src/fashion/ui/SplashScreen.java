package fashion.ui;

import fashion.util.AppTheme;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Animated splash screen shown on startup.
 */
public class SplashScreen extends JWindow {

    private JProgressBar progressBar;
    private JLabel statusLbl;
    private Timer animTimer;
    private int progress = 0;

    public SplashScreen() {
        setSize(520, 320);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0,0,new Color(20,10,45),getWidth(),getHeight(),new Color(80,20,80));
                g2.setPaint(gp);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),24,24);
            }
        };
        root.setOpaque(false);
        root.setBorder(AppTheme.padding(40, 50));

        // Logo emoji
        JLabel logo = new JLabel("👗", SwingConstants.CENTER);
        logo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 72));
        logo.setAlignmentX(CENTER_ALIGNMENT);

        JLabel appName = new JLabel("FASHION OUTFIT GENERATOR", SwingConstants.CENTER);
        appName.setFont(AppTheme.fontBold(22));
        appName.setForeground(Color.WHITE);

        JLabel tagline = new JLabel("Your personal AI style curator", SwingConstants.CENTER);
        tagline.setFont(AppTheme.fontItalic(13));
        tagline.setForeground(AppTheme.ACCENT_PINK);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(false);
        progressBar.setForeground(AppTheme.ACCENT_PINK);
        progressBar.setBackground(new Color(50, 30, 80));
        progressBar.setBorderPainted(false);
        progressBar.setPreferredSize(new Dimension(0, 5));

        statusLbl = AppTheme.label("Initialising wardrobe…", AppTheme.fontPlain(11), AppTheme.TEXT_MUTED);
        statusLbl.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setOpaque(false);
        logo.setAlignmentX(CENTER_ALIGNMENT);
        appName.setAlignmentX(CENTER_ALIGNMENT);
        tagline.setAlignmentX(CENTER_ALIGNMENT);
        statusLbl.setAlignmentX(CENTER_ALIGNMENT);
        progressBar.setAlignmentX(CENTER_ALIGNMENT);
        progressBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 5));

        center.add(logo);
        center.add(Box.createVerticalStrut(10));
        center.add(appName);
        center.add(Box.createVerticalStrut(6));
        center.add(tagline);
        center.add(Box.createVerticalStrut(30));
        center.add(progressBar);
        center.add(Box.createVerticalStrut(10));
        center.add(statusLbl);

        root.add(center, BorderLayout.CENTER);
        setContentPane(root);
    }

    public void animateAndLaunch(Runnable onComplete) {
        String[] messages = {
            "Loading wardrobe…", "Sorting items by season…",
            "Curating style palettes…", "Preparing outfit engine…", "Almost ready…"
        };
        setVisible(true);

        animTimer = new Timer(30, null);
        animTimer.addActionListener(e -> {
            progress += 2;
            progressBar.setValue(progress);
            int msgIdx = Math.min(progress / 22, messages.length - 1);
            statusLbl.setText(messages[msgIdx]);
            if (progress >= 100) {
                animTimer.stop();
                dispose();
                SwingUtilities.invokeLater(onComplete);
            }
        });
        animTimer.start();
    }
}
