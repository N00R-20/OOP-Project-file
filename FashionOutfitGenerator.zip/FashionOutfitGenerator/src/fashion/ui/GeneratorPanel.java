package fashion.ui;

import fashion.data.WardrobeManager;
import fashion.model.ClothingItem;
import fashion.model.ClothingItem.Season;
import fashion.model.ClothingItem.Style;
import fashion.model.Outfit;
import fashion.util.AppTheme;
import fashion.util.ImageLoader;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

/**
 * The main outfit generator panel – generates and displays outfit suggestions
 * with real fashion photography from Unsplash.
 */
public class GeneratorPanel extends JPanel {

    private WardrobeManager manager;
    private Outfit currentOutfit;

    private JComboBox<Style>   styleCB;
    private JComboBox<Season>  seasonCB;
    private JTextField         occasionField;
    private JPanel             outfitDisplay;
    private JLabel             outfitTitleLbl;
    private JLabel             outfitSubLbl;
    private JButton            generateBtn;
    private JButton            saveBtn;

    public GeneratorPanel() {
        manager = WardrobeManager.getInstance();
        setBackground(AppTheme.BG_DARK);
        setLayout(new BorderLayout(0, 16));
        setBorder(AppTheme.padding(24, 24));
        buildUI();
    }

    private void buildUI() {
        // ── Hero header ───────────────────────────────────────────────────────
        JPanel heroPanel = AppTheme.gradientPanel(new Color(80,30,120), new Color(180,50,100), false);
        heroPanel.setLayout(new BoxLayout(heroPanel, BoxLayout.Y_AXIS));
        heroPanel.setBorder(AppTheme.padding(28, 30, 22, 30));
        heroPanel.setPreferredSize(new Dimension(0, 140));

        JLabel heroTitle = AppTheme.label("✨  Outfit Generator", AppTheme.fontBold(30), Color.WHITE);
        JLabel heroSub   = AppTheme.label("Let AI curate your perfect look for any occasion",
                AppTheme.fontItalic(14), new Color(255, 220, 235));
        heroTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        heroSub.setAlignmentX(Component.LEFT_ALIGNMENT);
        heroPanel.add(heroTitle);
        heroPanel.add(Box.createVerticalStrut(8));
        heroPanel.add(heroSub);
        add(heroPanel, BorderLayout.NORTH);

        // ── Center: controls + output ─────────────────────────────────────────
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                buildControlPane(), buildOutputPane());
        split.setDividerLocation(300);
        split.setDividerSize(4);
        split.setBorder(null);
        split.setOpaque(false);
        add(split, BorderLayout.CENTER);
    }

    // ── Left control pane ─────────────────────────────────────────────────────
    private JPanel buildControlPane() {
        JPanel p = AppTheme.roundedPanel(AppTheme.BG_CARD, 20);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(AppTheme.padding(20, 20));

        addSection(p, "🎨  Style");
        styleCB = AppTheme.styledCombo(Style.values());
        styleCB.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        styleCB.setAlignmentX(LEFT_ALIGNMENT);
        p.add(styleCB);
        p.add(Box.createVerticalStrut(16));

        addSection(p, "🌸  Season");
        seasonCB = AppTheme.styledCombo(Season.values());
        seasonCB.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        seasonCB.setAlignmentX(LEFT_ALIGNMENT);
        p.add(seasonCB);
        p.add(Box.createVerticalStrut(16));

        addSection(p, "📍  Occasion");
        occasionField = AppTheme.styledField(16);
        occasionField.setText("Date Night");
        occasionField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        occasionField.setAlignmentX(LEFT_ALIGNMENT);
        p.add(occasionField);
        p.add(Box.createVerticalStrut(28));

        generateBtn = AppTheme.accentButton("✨  Generate Outfit", AppTheme.ACCENT_PINK, Color.WHITE);
        generateBtn.setAlignmentX(LEFT_ALIGNMENT);
        generateBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        generateBtn.setFont(AppTheme.fontBold(15));
        generateBtn.addActionListener(e -> generateOutfit());
        p.add(generateBtn);
        p.add(Box.createVerticalStrut(10));

        saveBtn = AppTheme.accentButton("💾  Save This Look", AppTheme.ACCENT_PURPLE, Color.WHITE);
        saveBtn.setAlignmentX(LEFT_ALIGNMENT);
        saveBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        saveBtn.setFont(AppTheme.fontBold(15));
        saveBtn.setEnabled(false);
        saveBtn.addActionListener(e -> saveOutfit());
        p.add(saveBtn);

        p.add(Box.createVerticalGlue());

        // Tip card
        p.add(Box.createVerticalStrut(20));
        JPanel tip = AppTheme.roundedPanel(new Color(60, 35, 80), 12);
        tip.setLayout(new BoxLayout(tip, BoxLayout.Y_AXIS));
        tip.setBorder(AppTheme.padding(12, 14));
        tip.setAlignmentX(LEFT_ALIGNMENT);
        tip.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        tip.add(AppTheme.label("💡 Tip", AppTheme.fontBold(12), AppTheme.ACCENT_GOLD));
        tip.add(Box.createVerticalStrut(6));
        JLabel tipText = AppTheme.label(
                "<html>Add more items to your wardrobe for more diverse outfit combinations!</html>",
                AppTheme.fontItalic(11), AppTheme.TEXT_MUTED);
        tip.add(tipText);
        p.add(tip);

        return p;
    }

    private void addSection(JPanel p, String text) {
        JLabel lbl = AppTheme.label(text, AppTheme.fontBold(13), AppTheme.TEXT_MUTED);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        p.add(lbl);
        p.add(Box.createVerticalStrut(6));
    }

    // ── Right output pane ─────────────────────────────────────────────────────
    private JPanel buildOutputPane() {
        JPanel outer = new JPanel(new BorderLayout(0, 12));
        outer.setOpaque(false);

        JPanel titleBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        titleBar.setOpaque(false);
        outfitTitleLbl = AppTheme.label("Your Outfit Will Appear Here",
                AppTheme.fontBold(20), AppTheme.TEXT_WHITE);
        outfitSubLbl   = AppTheme.label("Click 'Generate Outfit' to begin",
                AppTheme.fontItalic(13), AppTheme.TEXT_MUTED);
        JPanel titleStack = new JPanel();
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
        titleStack.setOpaque(false);
        titleStack.add(outfitTitleLbl);
        titleStack.add(Box.createVerticalStrut(4));
        titleStack.add(outfitSubLbl);
        titleBar.add(titleStack);
        outer.add(titleBar, BorderLayout.NORTH);

        // 3-column grid for item cards
        outfitDisplay = new JPanel(new GridLayout(0, 3, 12, 12));
        outfitDisplay.setOpaque(false);
        showPlaceholder();

        JScrollPane scroll = new JScrollPane(outfitDisplay);
        scroll.setBorder(null);
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        outer.add(scroll, BorderLayout.CENTER);

        return outer;
    }

    private void showPlaceholder() {
        outfitDisplay.removeAll();
        JPanel ph = AppTheme.roundedPanel(AppTheme.BG_CARD, 20);
        ph.setLayout(new BoxLayout(ph, BoxLayout.Y_AXIS));
        ph.setBorder(AppTheme.padding(40, 20));
        JLabel ic = new JLabel("👗", SwingConstants.CENTER);
        ic.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 60));
        ic.setAlignmentX(CENTER_ALIGNMENT);
        JLabel msg = AppTheme.label("Generate your first outfit!",
                AppTheme.fontItalic(14), AppTheme.TEXT_DIM);
        msg.setAlignmentX(CENTER_ALIGNMENT);
        ph.add(Box.createVerticalGlue());
        ph.add(ic);
        ph.add(Box.createVerticalStrut(12));
        ph.add(msg);
        ph.add(Box.createVerticalGlue());
        outfitDisplay.add(ph);
        outfitDisplay.revalidate();
        outfitDisplay.repaint();
    }

    // ── Generate ──────────────────────────────────────────────────────────────
    private void generateOutfit() {
        Style  style    = (Style)  styleCB.getSelectedItem();
        Season season   = (Season) seasonCB.getSelectedItem();
        String occasion = occasionField.getText().trim();
        if (occasion.isEmpty()) occasion = "Any";

        currentOutfit = manager.generateOutfit(style, season, occasion);
        List<ClothingItem> items = currentOutfit.getItems();

        outfitTitleLbl.setText(currentOutfit.getName());
        outfitSubLbl.setText(style + "  ·  " + season + "  ·  " + occasion
                + "  ·  " + items.size() + " pieces");

        outfitDisplay.removeAll();
        if (items.isEmpty()) {
            JLabel empty = AppTheme.label("No matching items found. Add more clothes!",
                    AppTheme.fontItalic(14), AppTheme.ACCENT_PINK);
            outfitDisplay.add(empty);
        } else {
            for (ClothingItem item : items) {
                outfitDisplay.add(buildItemCard(item));
            }
        }
        outfitDisplay.revalidate();
        outfitDisplay.repaint();
        saveBtn.setEnabled(!items.isEmpty());

        // Quick colour-flash on generate button
        Timer t = new Timer(80, null);
        final int[] count = {0};
        t.addActionListener(ae -> {
            if (++count[0] >= 6) t.stop();
        });
        t.start();
    }

    // ── Item card with real photo ─────────────────────────────────────────────
    private JPanel buildItemCard(ClothingItem item) {
        JPanel card = new JPanel(new BorderLayout(0, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(AppTheme.BG_CARD);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 18, 18));
            }
        };
        card.setOpaque(false);

        // ── Photo area ────────────────────────────────────────────────────────
        JLabel photoLbl = new JLabel(ImageLoader.makePlaceholderPublic(
                item.getName(), item.getCategory(), 180, 200), SwingConstants.CENTER);
        photoLbl.setPreferredSize(new Dimension(180, 200));
        photoLbl.setOpaque(false);

        // Load real image asynchronously
        ImageLoader.loadAsync(item.getName(), item.getCategory(), 180, 200, icon -> {
            photoLbl.setIcon(icon);
            photoLbl.revalidate();
            photoLbl.repaint();
        });

        // Rounded photo wrapper
        JPanel photoWrapper = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Top rounded clip
                Shape clip = new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 18, 18);
                g2.setClip(clip);
                super.paintComponent(g);
            }
        };
        photoWrapper.setOpaque(false);
        photoWrapper.setPreferredSize(new Dimension(180, 200));
        photoWrapper.add(photoLbl, BorderLayout.CENTER);
        card.add(photoWrapper, BorderLayout.CENTER);

        // ── Info strip ────────────────────────────────────────────────────────
        JPanel info = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(20, 15, 35, 230));
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 0, 0));
                // bottom corners rounded
                g2.fillRect(0, 0, getWidth(), getHeight() - 18);
                g2.fill(new RoundRectangle2D.Float(0, getHeight()-18, getWidth(), 18, 18, 18));
                super.paintComponent(g);
            }
        };
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setOpaque(false);
        info.setBorder(AppTheme.padding(10, 12, 12, 12));

        // Category badge
        JLabel catBadge = new JLabel(item.getCategory().getDisplayName().toUpperCase());
        catBadge.setFont(AppTheme.fontBold(9));
        catBadge.setForeground(AppTheme.ACCENT_PINK);
        catBadge.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(AppTheme.ACCENT_PINK, 1, true),
                AppTheme.padding(1, 5)));
        catBadge.setAlignmentX(LEFT_ALIGNMENT);

        // Name
        JLabel nameLbl = AppTheme.label(item.getName(), AppTheme.fontBold(13), AppTheme.TEXT_WHITE);
        nameLbl.setAlignmentX(LEFT_ALIGNMENT);

        // Brand + color
        JLabel brandLbl = AppTheme.label(item.getBrand(), AppTheme.fontPlain(11), AppTheme.TEXT_MUTED);
        brandLbl.setAlignmentX(LEFT_ALIGNMENT);

        // Color dot
        JPanel colorRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        colorRow.setOpaque(false);
        colorRow.setAlignmentX(LEFT_ALIGNMENT);
        JLabel dot = new JLabel("●");
        dot.setFont(AppTheme.fontBold(12));
        dot.setForeground(AppTheme.colorForName(item.getColor()).brighter());
        JLabel colorLbl = AppTheme.label(item.getColor(), AppTheme.fontPlain(11), AppTheme.TEXT_MUTED);
        colorRow.add(dot);
        colorRow.add(colorLbl);

        info.add(catBadge);
        info.add(Box.createVerticalStrut(5));
        info.add(nameLbl);
        info.add(Box.createVerticalStrut(2));
        info.add(brandLbl);
        info.add(Box.createVerticalStrut(4));
        info.add(colorRow);

        card.add(info, BorderLayout.SOUTH);
        return card;
    }

    private void saveOutfit() {
        if (currentOutfit == null) return;
        String name = JOptionPane.showInputDialog(this, "Name this outfit:", currentOutfit.getName());
        if (name != null && !name.trim().isEmpty()) currentOutfit.setName(name.trim());
        manager.saveOutfit(currentOutfit);
        JOptionPane.showMessageDialog(this,
                "✨ Outfit \"" + currentOutfit.getName() + "\" saved!",
                "Saved", JOptionPane.INFORMATION_MESSAGE);
        currentOutfit = null;
        saveBtn.setEnabled(false);
    }
}
