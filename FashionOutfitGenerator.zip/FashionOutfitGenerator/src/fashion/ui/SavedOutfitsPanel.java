package fashion.ui;

import fashion.data.WardrobeManager;
import fashion.model.ClothingItem;
import fashion.model.Outfit;
import fashion.util.AppTheme;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.List;

/**
 * Displays all saved outfits in a card-based gallery.
 */
public class SavedOutfitsPanel extends JPanel {

    private WardrobeManager manager;
    private JPanel gallery;
    private JLabel countLbl;

    public SavedOutfitsPanel() {
        manager = WardrobeManager.getInstance();
        setBackground(AppTheme.BG_DARK);
        setLayout(new BorderLayout(0, 16));
        setBorder(AppTheme.padding(20, 24));
        buildUI();
    }

    private void buildUI() {
        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = AppTheme.label("💾  Saved Outfits", AppTheme.fontBold(24), AppTheme.TEXT_WHITE);
        countLbl = AppTheme.label("0 looks saved", AppTheme.fontItalic(13), AppTheme.TEXT_MUTED);
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 4));
        left.setOpaque(false); left.add(title);
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 4));
        right.setOpaque(false);
        JButton refreshBtn = AppTheme.accentButton("↻ Refresh", AppTheme.ACCENT_PURPLE, Color.WHITE);
        refreshBtn.addActionListener(e -> refreshGallery());
        right.add(refreshBtn);
        header.add(left, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        header.add(countLbl, BorderLayout.SOUTH);
        add(header, BorderLayout.NORTH);

        // Gallery
        gallery = new JPanel(new GridLayout(0, 2, 16, 16));
        gallery.setOpaque(false);

        JScrollPane scroll = new JScrollPane(gallery);
        scroll.setBorder(null);
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        refreshGallery();
    }

    public void refreshGallery() {
        gallery.removeAll();
        List<Outfit> outfits = manager.getSavedOutfits();
        countLbl.setText(outfits.size() + " look" + (outfits.size() == 1 ? "" : "s") + " saved");

        if (outfits.isEmpty()) {
            JPanel empty = AppTheme.roundedPanel(AppTheme.BG_CARD, 18);
            empty.setLayout(new BoxLayout(empty, BoxLayout.Y_AXIS));
            empty.setBorder(AppTheme.padding(50, 30));
            JLabel ic  = new JLabel("🌟", SwingConstants.CENTER);
            ic.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 56));
            ic.setAlignmentX(CENTER_ALIGNMENT);
            JLabel msg = AppTheme.label("No saved outfits yet. Generate one!", AppTheme.fontItalic(14), AppTheme.TEXT_DIM);
            msg.setAlignmentX(CENTER_ALIGNMENT);
            empty.add(Box.createVerticalGlue());
            empty.add(ic);
            empty.add(Box.createVerticalStrut(12));
            empty.add(msg);
            empty.add(Box.createVerticalGlue());
            gallery.add(empty);
        } else {
            for (Outfit o : outfits) gallery.add(buildOutfitCard(o));
        }
        gallery.revalidate();
        gallery.repaint();
    }

    private JPanel buildOutfitCard(Outfit outfit) {
        JPanel card = AppTheme.roundedPanel(AppTheme.BG_CARD, 18);
        card.setLayout(new BorderLayout(0, 10));
        card.setBorder(AppTheme.padding(16, 18));

        // Card header
        JPanel cardTop = new JPanel(new BorderLayout());
        cardTop.setOpaque(false);
        JLabel nameL = AppTheme.label(outfit.getName(), AppTheme.fontBold(16), AppTheme.TEXT_WHITE);
        JLabel favL  = new JLabel(outfit.isFavorite() ? "♥" : "♡");
        favL.setFont(AppTheme.fontBold(18));
        favL.setForeground(AppTheme.ACCENT_PINK);
        favL.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        favL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                outfit.setFavorite(!outfit.isFavorite());
                favL.setText(outfit.isFavorite() ? "♥" : "♡");
            }
        });
        cardTop.add(nameL, BorderLayout.CENTER);
        cardTop.add(favL, BorderLayout.EAST);
        card.add(cardTop, BorderLayout.NORTH);

        // Tags
        JPanel tags = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        tags.setOpaque(false);
        tags.add(makeTag(outfit.getStyle().toString(), AppTheme.ACCENT_PURPLE));
        tags.add(makeTag(outfit.getSeason().toString(), AppTheme.ACCENT_PINK));
        tags.add(makeTag(outfit.getOccasion(), AppTheme.ACCENT_GOLD));
        card.add(tags, BorderLayout.AFTER_LINE_ENDS); // placeholder

        // Items list
        JPanel itemsPanel = new JPanel();
        itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS));
        itemsPanel.setOpaque(false);
        itemsPanel.add(tags);
        itemsPanel.add(Box.createVerticalStrut(10));

        for (ClothingItem item : outfit.getItems()) {
            JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
            row.setOpaque(false);
            JLabel dot = new JLabel("●");
            dot.setFont(AppTheme.fontBold(10));
            dot.setForeground(AppTheme.colorForName(item.getColor()));
            JLabel itemLbl = AppTheme.label(item.getName() + "  —  " + item.getBrand(),
                    AppTheme.fontPlain(12), AppTheme.TEXT_WHITE);
            JLabel catLbl  = AppTheme.label(item.getCategory().getDisplayName(),
                    AppTheme.fontItalic(11), AppTheme.TEXT_MUTED);
            row.add(dot); row.add(itemLbl); row.add(catLbl);
            itemsPanel.add(row);
        }

        card.add(itemsPanel, BorderLayout.CENTER);

        // Footer: date + delete
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.setBorder(BorderFactory.createMatteBorder(1,0,0,0, new Color(60,50,90)));
        footer.setBorder(AppTheme.padding(8,0,0,0));
        JLabel dateLbl = AppTheme.label("Created: " + outfit.getDateCreated(),
                AppTheme.fontPlain(11), AppTheme.TEXT_DIM);
        JButton delBtn = AppTheme.accentButton("Remove", new Color(160,40,60), Color.WHITE);
        delBtn.setFont(AppTheme.fontBold(11));
        delBtn.addActionListener(e -> {
            manager.removeOutfit(outfit.getId());
            refreshGallery();
        });
        footer.add(dateLbl, BorderLayout.WEST);
        footer.add(delBtn, BorderLayout.EAST);
        card.add(footer, BorderLayout.SOUTH);

        return card;
    }

    private JLabel makeTag(String text, Color color) {
        JLabel tag = new JLabel(text);
        tag.setFont(AppTheme.fontBold(10));
        tag.setForeground(color);
        tag.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(color, 1, true),
                AppTheme.padding(2, 8)));
        return tag;
    }
}
