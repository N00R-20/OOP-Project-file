package fashion.ui;

import fashion.data.WardrobeManager;
import fashion.model.ClothingItem;
import fashion.model.ClothingItem.Category;
import fashion.model.ClothingItem.Season;
import fashion.model.ClothingItem.Style;
import fashion.util.AppTheme;
import fashion.util.ImageLoader;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

/**
 * Wardrobe panel – shows items as photo cards in a grid with search/filter.
 */
public class WardrobePanel extends JPanel {

    private WardrobeManager manager;
    private JPanel grid;
    private JTextField searchField;
    private JComboBox<String> categoryFilter;
    private JLabel countLbl;

    public WardrobePanel() {
        manager = WardrobeManager.getInstance();
        setBackground(AppTheme.BG_DARK);
        setLayout(new BorderLayout(0, 12));
        setBorder(AppTheme.padding(20, 20));
        buildUI();
        refreshGrid(manager.getAllItems());
    }

    private void buildUI() {
        // ── Header ────────────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout(10, 6));
        header.setOpaque(false);

        JLabel title = AppTheme.label("👗  My Wardrobe", AppTheme.fontBold(24), AppTheme.TEXT_WHITE);
        countLbl = AppTheme.label("", AppTheme.fontItalic(12), AppTheme.TEXT_MUTED);
        JPanel titleCol = new JPanel();
        titleCol.setLayout(new BoxLayout(titleCol, BoxLayout.Y_AXIS));
        titleCol.setOpaque(false);
        titleCol.add(title);
        titleCol.add(countLbl);
        header.add(titleCol, BorderLayout.WEST);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        JButton addBtn = AppTheme.accentButton("＋ Add Item", AppTheme.ACCENT_PINK, Color.WHITE);
        addBtn.addActionListener(e -> showAddDialog());
        JButton delBtn = AppTheme.accentButton("🗑 Remove", new Color(180, 50, 70), Color.WHITE);
        delBtn.addActionListener(e -> removeSelected());
        btnRow.add(delBtn);
        btnRow.add(addBtn);
        header.add(btnRow, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // ── Filter bar ────────────────────────────────────────────────────────
        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4));
        filterBar.setOpaque(false);

        searchField = AppTheme.styledField(22);
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { applyFilter(); }
        });

        String[] cats = {"All Categories","Tops","Bottoms","Dresses",
                "Outerwear","Shoes","Accessories","Bags"};
        categoryFilter = AppTheme.styledCombo(cats);
        categoryFilter.addActionListener(e -> applyFilter());

        filterBar.add(AppTheme.label("🔍", AppTheme.fontBold(14), AppTheme.TEXT_MUTED));
        filterBar.add(searchField);
        filterBar.add(AppTheme.label("Category:", AppTheme.fontBold(12), AppTheme.TEXT_MUTED));
        filterBar.add(categoryFilter);
        add(filterBar, BorderLayout.AFTER_LINE_ENDS); // used below

        // ── Grid ──────────────────────────────────────────────────────────────
        grid = new JPanel(new GridLayout(0, 4, 12, 12));
        grid.setOpaque(false);

        JScrollPane scroll = new JScrollPane(grid);
        scroll.setBorder(null);
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(20);

        JPanel center = new JPanel(new BorderLayout(0, 8));
        center.setOpaque(false);
        center.add(filterBar, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        // Stats strip
        JPanel stats = buildStatsStrip();
        center.add(stats, BorderLayout.SOUTH);
        add(center, BorderLayout.CENTER);
    }

    // ── Photo card (used in wardrobe grid) ────────────────────────────────────
    private JPanel buildPhotoCard(ClothingItem item) {
        JPanel card = new JPanel(new BorderLayout(0, 0)) {
            boolean hovered = false;
            {
                addMouseListener(new MouseAdapter() {
                    public void mouseEntered(MouseEvent e) { hovered = true; repaint(); }
                    public void mouseExited(MouseEvent e)  { hovered = false; repaint(); }
                });
            }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(hovered ? new Color(45, 35, 65) : AppTheme.BG_CARD);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                if (hovered) {
                    g2.setColor(AppTheme.ACCENT_PINK);
                    g2.setStroke(new BasicStroke(1.5f));
                    g2.draw(new RoundRectangle2D.Float(1, 1, getWidth()-2, getHeight()-2, 16, 16));
                }
            }
        };
        card.setOpaque(false);
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Photo
        JLabel photo = new JLabel(ImageLoader.makePlaceholderPublic(
                item.getName(), item.getCategory(), 150, 170), SwingConstants.CENTER);
        photo.setPreferredSize(new Dimension(150, 170));
        photo.setOpaque(false);
        ImageLoader.loadAsync(item.getName(), item.getCategory(), 150, 170, icon -> {
            photo.setIcon(icon);
            photo.revalidate();
            photo.repaint();
        });

        JPanel photoWrap = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setClip(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                super.paintComponent(g);
            }
        };
        photoWrap.setOpaque(false);
        photoWrap.add(photo, BorderLayout.CENTER);

        // Fav badge
        if (item.isFavorite()) {
            JLabel fav = new JLabel("♥");
            fav.setFont(AppTheme.fontBold(14));
            fav.setForeground(AppTheme.ACCENT_PINK);
            fav.setOpaque(true);
            fav.setBackground(new Color(30, 20, 50, 200));
            fav.setBorder(AppTheme.padding(3, 6));
            JPanel overlay = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 6));
            overlay.setOpaque(false);
            overlay.add(fav);
            photoWrap.add(overlay, BorderLayout.NORTH);
        }

        // Info
        JPanel info = new JPanel();
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setOpaque(false);
        info.setBorder(AppTheme.padding(8, 10, 10, 10));

        JLabel nameLbl = AppTheme.label(item.getName(), AppTheme.fontBold(12), AppTheme.TEXT_WHITE);
        nameLbl.setAlignmentX(LEFT_ALIGNMENT);
        JLabel brandLbl = AppTheme.label(item.getBrand(), AppTheme.fontPlain(11), AppTheme.TEXT_MUTED);
        brandLbl.setAlignmentX(LEFT_ALIGNMENT);

        JPanel dotRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
        dotRow.setOpaque(false);
        dotRow.setAlignmentX(LEFT_ALIGNMENT);
        JLabel dot = new JLabel("●");
        dot.setFont(AppTheme.fontBold(9));
        dot.setForeground(AppTheme.colorForName(item.getColor()));
        dotRow.add(dot);
        dotRow.add(AppTheme.label(item.getColor(), AppTheme.fontPlain(10), AppTheme.TEXT_DIM));

        JLabel styleLbl = AppTheme.label(item.getStyle().toString(), AppTheme.fontItalic(10), AppTheme.ACCENT_PURPLE);
        styleLbl.setAlignmentX(LEFT_ALIGNMENT);

        info.add(nameLbl);
        info.add(Box.createVerticalStrut(2));
        info.add(brandLbl);
        info.add(Box.createVerticalStrut(3));
        info.add(dotRow);
        info.add(styleLbl);

        card.add(photoWrap, BorderLayout.CENTER);
        card.add(info, BorderLayout.SOUTH);

        // Click to toggle favourite
        card.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    item.setFavorite(!item.isFavorite());
                    refreshGrid(getCurrentList());
                }
            }
        });
        return card;
    }

    private List<ClothingItem> getCurrentList() {
        String q = searchField.getText().trim();
        return q.isEmpty() ? manager.getAllItems() : manager.search(q);
    }

    private void refreshGrid(List<ClothingItem> items) {
        grid.removeAll();
        countLbl.setText(items.size() + " item" + (items.size() == 1 ? "" : "s"));
        for (ClothingItem item : items) grid.add(buildPhotoCard(item));
        grid.revalidate();
        grid.repaint();
    }

    private void applyFilter() {
        String q = searchField.getText().trim();
        String catSel = (String) categoryFilter.getSelectedItem();
        List<ClothingItem> items = q.isEmpty() ? manager.getAllItems() : manager.search(q);
        if (catSel != null && !catSel.equals("All Categories")) {
            for (Category c : Category.values()) {
                if (c.getDisplayName().startsWith(catSel.substring(0, Math.min(4, catSel.length())))) {
                    final Category fc = c;
                    items = new java.util.ArrayList<>(items);
                    items.removeIf(i -> i.getCategory() != fc);
                    break;
                }
            }
        }
        refreshGrid(items);
    }

    private JPanel buildStatsStrip() {
        JPanel strip = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 6));
        strip.setOpaque(false);
        strip.setBorder(BorderFactory.createMatteBorder(1,0,0,0, new Color(60,50,90)));
        java.util.Map<String, Integer> stats = manager.getCategoryStats();
        for (java.util.Map.Entry<String, Integer> e : stats.entrySet()) {
            if (e.getValue() > 0)
                strip.add(AppTheme.label(e.getKey() + ": " + e.getValue(),
                        AppTheme.fontPlain(12), AppTheme.TEXT_MUTED));
        }
        strip.add(AppTheme.label("♥ Favourites: " + manager.getFavoriteItems().size(),
                AppTheme.fontBold(12), AppTheme.ACCENT_PINK));
        return strip;
    }

    private void showAddDialog() {
        JDialog dlg = new JDialog(SwingUtilities.getWindowAncestor(this),
                "Add Clothing Item", Dialog.ModalityType.APPLICATION_MODAL);
        dlg.setSize(460, 520);
        dlg.setLocationRelativeTo(this);

        JPanel content = new JPanel(new GridBagLayout());
        content.setBackground(AppTheme.BG_CARD);
        content.setBorder(AppTheme.padding(20, 24));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6,6,6,6);
        gc.fill = GridBagConstraints.HORIZONTAL;

        JTextField nameF  = AppTheme.styledField(18);
        JTextField brandF = AppTheme.styledField(18);
        JTextField colorF = AppTheme.styledField(18);
        JTextArea  descF  = AppTheme.styledArea(3, 18);
        JComboBox<Category> catCB = AppTheme.styledCombo(Category.values());
        JComboBox<Season>   seaCB = AppTheme.styledCombo(Season.values());
        JComboBox<Style>    styCB = AppTheme.styledCombo(Style.values());

        String[]     labels = {"Name *","Brand","Color","Category","Season","Style","Description"};
        JComponent[] fields = {nameF, brandF, colorF, catCB, seaCB, styCB, new JScrollPane(descF)};

        for (int i = 0; i < labels.length; i++) {
            gc.gridx=0; gc.gridy=i; gc.weightx=0;
            content.add(AppTheme.label(labels[i], AppTheme.fontBold(13), AppTheme.TEXT_MUTED), gc);
            gc.gridx=1; gc.weightx=1;
            fields[i].setBackground(AppTheme.BG_CARD2);
            content.add(fields[i], gc);
        }

        JButton saveBtn = AppTheme.accentButton("✔ Save Item", AppTheme.ACCENT_PINK, Color.WHITE);
        saveBtn.addActionListener(e -> {
            String name = nameF.getText().trim();
            if (name.isEmpty()) { JOptionPane.showMessageDialog(dlg,"Name is required!"); return; }
            manager.addClothingItem(new ClothingItem(
                    manager.nextId(), name,
                    brandF.getText().isEmpty() ? "Unknown" : brandF.getText().trim(),
                    colorF.getText().isEmpty() ? "N/A"     : colorF.getText().trim(),
                    (Category)catCB.getSelectedItem(),
                    (Season)  seaCB.getSelectedItem(),
                    (Style)   styCB.getSelectedItem(),
                    descF.getText().trim()));
            refreshGrid(manager.getAllItems());
            dlg.dispose();
        });

        gc.gridx=0; gc.gridy=labels.length; gc.gridwidth=2;
        gc.insets=new Insets(16,6,6,6);
        content.add(saveBtn, gc);

        dlg.setContentPane(new JScrollPane(content));
        dlg.getContentPane().setBackground(AppTheme.BG_CARD);
        dlg.setVisible(true);
    }

    // Track selected item for removal (via right-click popup or button)
    private ClothingItem selectedForRemoval = null;

    private void removeSelected() {
        String name = JOptionPane.showInputDialog(this,
                "Enter exact item name to remove:", "Remove Item", JOptionPane.PLAIN_MESSAGE);
        if (name == null || name.trim().isEmpty()) return;
        List<ClothingItem> found = manager.search(name.trim());
        if (found.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No item found with that name.");
            return;
        }
        ClothingItem item = found.get(0);
        int ok = JOptionPane.showConfirmDialog(this,
                "Remove \"" + item.getName() + "\"?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            manager.removeClothingItem(item.getId());
            refreshGrid(manager.getAllItems());
        }
    }
}
