package fashion.ui;

import fashion.util.AppTheme;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Main application window – hosts the sidebar navigation and card-panel content area.
 */
public class MainWindow extends JFrame {

    private JPanel contentArea;
    private CardLayout cards;
    private JLabel currentPageTitle;

    // Nav panels
    private GeneratorPanel  generatorPanel;
    private WardrobePanel   wardrobePanel;
    private SavedOutfitsPanel savedPanel;
    private ProfilePanel    profilePanel;

    private static final String PANEL_GENERATOR = "generator";
    private static final String PANEL_WARDROBE  = "wardrobe";
    private static final String PANEL_SAVED     = "saved";
    private static final String PANEL_PROFILE   = "profile";

    public MainWindow() {
        setTitle("Fashion Outfit Generator ✨");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 760);
        setMinimumSize(new Dimension(900, 620));
        setLocationRelativeTo(null);

        AppTheme.applyGlobalDefaults();
        getContentPane().setBackground(AppTheme.BG_DARK);
        setLayout(new BorderLayout());

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMainArea(), BorderLayout.CENTER);

        // Open on generator tab
        showPanel(PANEL_GENERATOR);
    }

    // ── Sidebar ───────────────────────────────────────────────────────────────
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0,0,new Color(30,15,55),0,getHeight(),new Color(15,10,30));
                g2.setPaint(gp);
                g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBorder(AppTheme.padding(0, 0, 0, 0));

        // Logo area
        JPanel logo = new JPanel(new BorderLayout());
        logo.setOpaque(false);
        logo.setBorder(AppTheme.padding(28, 22, 20, 22));

        JLabel logoIcon = new JLabel("👗", SwingConstants.LEFT);
        logoIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 32));

        JPanel logoText = new JPanel();
        logoText.setLayout(new BoxLayout(logoText, BoxLayout.Y_AXIS));
        logoText.setOpaque(false);
        JLabel appName = AppTheme.label("FASHION", AppTheme.fontBold(16), AppTheme.TEXT_WHITE);
        JLabel appSub  = AppTheme.label("Outfit Generator", AppTheme.fontItalic(11), AppTheme.ACCENT_PINK);
        logoText.add(appName);
        logoText.add(appSub);

        logo.add(logoIcon, BorderLayout.WEST);
        logo.add(logoText, BorderLayout.CENTER);
        sidebar.add(logo);

        // Divider
        sidebar.add(makeDivider());
        sidebar.add(Box.createVerticalStrut(12));

        // Nav items
        JButton[] navBtns = new JButton[4];
        navBtns[0] = navButton("✨  Generator", PANEL_GENERATOR, navBtns, 0);
        navBtns[1] = navButton("👗  Wardrobe",  PANEL_WARDROBE,  navBtns, 1);
        navBtns[2] = navButton("💾  Saved Looks", PANEL_SAVED,   navBtns, 2);
        navBtns[3] = navButton("👤  Profile",   PANEL_PROFILE,   navBtns, 3);

        for (JButton b : navBtns) sidebar.add(b);

        sidebar.add(Box.createVerticalGlue());

        // Footer
        sidebar.add(makeDivider());
        JLabel footer = AppTheme.label("  © 2025 FashionGen", AppTheme.fontPlain(10), AppTheme.TEXT_DIM);
        footer.setBorder(AppTheme.padding(10,22,14,22));
        sidebar.add(footer);

        return sidebar;
    }

    private JButton navButton(String text, String panel, JButton[] allBtns, int idx) {
        JButton btn = new JButton(text) {
            boolean active = false;
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                if (active || getModel().isRollover()) {
                    GradientPaint gp = new GradientPaint(0,0,new Color(120,50,180,160),getWidth(),0,new Color(220,80,130,130));
                    g2.setPaint(gp);
                    g2.fill(new RoundRectangle2D.Float(8,2,getWidth()-16,getHeight()-4,12,12));
                    // Left accent bar
                    g2.setColor(AppTheme.ACCENT_PINK);
                    g2.fillRoundRect(0,8,4,getHeight()-16,4,4);
                }
                super.paintComponent(g);
            }
            public void setActive(boolean a) { active = a; repaint(); }
        };
        btn.setFont(AppTheme.fontBold(13));
        btn.setForeground(AppTheme.TEXT_MUTED);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.setBorder(AppTheme.padding(13, 22, 13, 22));

        btn.addActionListener(e -> {
            showPanel(panel);
            for (JButton b : allBtns) {
                if (b instanceof JButton) {
                    try {
                        b.getClass().getMethod("setActive", boolean.class).invoke(b, false);
                        b.setForeground(AppTheme.TEXT_MUTED);
                    } catch (Exception ex) {}
                }
            }
            try {
                btn.getClass().getMethod("setActive", boolean.class).invoke(btn, true);
            } catch (Exception ex) {}
            btn.setForeground(AppTheme.TEXT_WHITE);
        });
        return btn;
    }

    private JSeparator makeDivider() {
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(60,50,90));
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        return sep;
    }

    // ── Main content area ─────────────────────────────────────────────────────
    private JPanel buildMainArea() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(AppTheme.BG_DARK);

        // Top bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(20, 16, 34));
        topBar.setBorder(AppTheme.padding(14, 24, 14, 24));
        topBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0,0,1,0, new Color(50,40,80)),
                AppTheme.padding(12,24,12,24)));

        currentPageTitle = AppTheme.label("✨  Outfit Generator", AppTheme.fontBold(18), AppTheme.TEXT_WHITE);
        JLabel clock = AppTheme.label(java.time.LocalDate.now().toString(),
                AppTheme.fontPlain(12), AppTheme.TEXT_DIM);

        topBar.add(currentPageTitle, BorderLayout.WEST);
        topBar.add(clock, BorderLayout.EAST);
        main.add(topBar, BorderLayout.NORTH);

        // Card layout area
        cards = new CardLayout();
        contentArea = new JPanel(cards);
        contentArea.setBackground(AppTheme.BG_DARK);

        generatorPanel = new GeneratorPanel();
        wardrobePanel  = new WardrobePanel();
        savedPanel     = new SavedOutfitsPanel();
        profilePanel   = new ProfilePanel();

        contentArea.add(generatorPanel, PANEL_GENERATOR);
        contentArea.add(wardrobePanel,  PANEL_WARDROBE);
        contentArea.add(savedPanel,     PANEL_SAVED);
        contentArea.add(profilePanel,   PANEL_PROFILE);

        main.add(contentArea, BorderLayout.CENTER);
        return main;
    }

    private void showPanel(String name) {
        cards.show(contentArea, name);
        switch (name) {
            case PANEL_GENERATOR: currentPageTitle.setText("✨  Outfit Generator"); break;
            case PANEL_WARDROBE:  currentPageTitle.setText("👗  My Wardrobe"); break;
            case PANEL_SAVED:
                currentPageTitle.setText("💾  Saved Looks");
                savedPanel.refreshGallery();
                break;
            case PANEL_PROFILE:   currentPageTitle.setText("👤  My Profile"); break;
        }
    }
}
