package fashion.ui;

import fashion.data.WardrobeManager;
import fashion.model.ClothingItem;
import fashion.model.UserProfile;
import fashion.util.AppTheme;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.Map;

/**
 * User profile panel with style preferences and wardrobe statistics.
 */
public class ProfilePanel extends JPanel {

    private WardrobeManager manager;
    private JTextField nameField;
    private JTextField usernameField;
    private JComboBox<UserProfile.BodyType> bodyTypeCB;
    private JComboBox<ClothingItem.Season> seasonCB;

    public ProfilePanel() {
        manager = WardrobeManager.getInstance();
        setBackground(AppTheme.BG_DARK);
        setLayout(new BorderLayout(16, 16));
        setBorder(AppTheme.padding(20, 24));
        buildUI();
    }

    private void buildUI() {
        // Header
        JLabel title = AppTheme.label("👤  My Profile", AppTheme.fontBold(24), AppTheme.TEXT_WHITE);
        add(title, BorderLayout.NORTH);

        // Main content
        JPanel content = new JPanel(new GridLayout(1, 2, 20, 0));
        content.setOpaque(false);
        content.add(buildProfileForm());
        content.add(buildStatsPanel());
        add(content, BorderLayout.CENTER);
    }

    private JPanel buildProfileForm() {
        JPanel card = AppTheme.roundedPanel(AppTheme.BG_CARD, 20);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(AppTheme.padding(24, 24));

        UserProfile profile = manager.getUserProfile();

        // Avatar circle
        JLabel avatar = new JLabel(profile.getProfileEmoji(), SwingConstants.CENTER);
        avatar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 64));
        avatar.setAlignmentX(CENTER_ALIGNMENT);
        avatar.setPreferredSize(new Dimension(100, 100));

        // Gradient avatar bg
        JPanel avatarBg = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0,0,AppTheme.ACCENT_PURPLE,getWidth(),getHeight(),AppTheme.ACCENT_PINK);
                g2.setPaint(gp);
                g2.fillOval(0,0,getWidth(),getHeight());
            }
        };
        avatarBg.setOpaque(false);
        avatarBg.setPreferredSize(new Dimension(110,110));
        avatarBg.setMaximumSize(new Dimension(110,110));
        avatarBg.add(avatar, BorderLayout.CENTER);
        avatarBg.setAlignmentX(CENTER_ALIGNMENT);
        card.add(avatarBg);
        card.add(Box.createVerticalStrut(16));

        // Emoji picker
        JPanel emojiRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        emojiRow.setOpaque(false);
        String[] emojis = {"👗","👠","💄","👒","💅","🌸","✨","👑"};
        for (String em : emojis) {
            JButton b = new JButton(em);
            b.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
            b.setPreferredSize(new Dimension(36,36));
            b.setBackground(AppTheme.BG_CARD2);
            b.setBorderPainted(false);
            b.setFocusPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addActionListener(e -> { avatar.setText(em); profile.setProfileEmoji(em); });
            emojiRow.add(b);
        }
        emojiRow.setAlignmentX(CENTER_ALIGNMENT);
        card.add(emojiRow);
        card.add(Box.createVerticalStrut(20));

        // Form fields
        JLabel formTitle = AppTheme.label("Personal Details", AppTheme.fontBold(15), AppTheme.ACCENT_PINK);
        formTitle.setAlignmentX(LEFT_ALIGNMENT);
        card.add(formTitle);
        card.add(Box.createVerticalStrut(12));

        nameField = AppTheme.styledField(20);
        nameField.setText(profile.getFullName());
        nameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        nameField.setAlignmentX(LEFT_ALIGNMENT);

        usernameField = AppTheme.styledField(20);
        usernameField.setText(profile.getUsername());
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        usernameField.setAlignmentX(LEFT_ALIGNMENT);

        bodyTypeCB = AppTheme.styledCombo(UserProfile.BodyType.values());
        bodyTypeCB.setSelectedItem(profile.getBodyType());
        bodyTypeCB.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        bodyTypeCB.setAlignmentX(LEFT_ALIGNMENT);

        seasonCB = AppTheme.styledCombo(ClothingItem.Season.values());
        seasonCB.setSelectedItem(profile.getPreferredSeason());
        seasonCB.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        seasonCB.setAlignmentX(LEFT_ALIGNMENT);

        addFieldRow(card, "Full Name", nameField);
        addFieldRow(card, "Username", usernameField);
        addFieldRow(card, "Body Type", bodyTypeCB);
        addFieldRow(card, "Fav Season", seasonCB);

        card.add(Box.createVerticalStrut(20));

        JButton saveBtn = AppTheme.accentButton("💾  Save Profile", AppTheme.ACCENT_PINK, Color.WHITE);
        saveBtn.setAlignmentX(LEFT_ALIGNMENT);
        saveBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        saveBtn.addActionListener(e -> saveProfile());
        card.add(saveBtn);
        card.add(Box.createVerticalGlue());

        return card;
    }

    private void addFieldRow(JPanel p, String label, JComponent field) {
        JLabel lbl = AppTheme.label(label, AppTheme.fontBold(12), AppTheme.TEXT_MUTED);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        p.add(lbl);
        p.add(Box.createVerticalStrut(4));
        p.add(field);
        p.add(Box.createVerticalStrut(12));
    }

    private JPanel buildStatsPanel() {
        JPanel col = new JPanel();
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        col.setOpaque(false);

        // Overview stats
        JPanel statsCard = AppTheme.roundedPanel(AppTheme.BG_CARD, 20);
        statsCard.setLayout(new BoxLayout(statsCard, BoxLayout.Y_AXIS));
        statsCard.setBorder(AppTheme.padding(22, 22));

        JLabel statsTitle = AppTheme.label("📊  Wardrobe Stats", AppTheme.fontBold(16), AppTheme.ACCENT_PURPLE);
        statsTitle.setAlignmentX(LEFT_ALIGNMENT);
        statsCard.add(statsTitle);
        statsCard.add(Box.createVerticalStrut(16));

        addStatRow(statsCard, "Total Items", String.valueOf(manager.getTotalItems()), AppTheme.ACCENT_PINK);
        addStatRow(statsCard, "Saved Outfits", String.valueOf(manager.getTotalOutfits()), AppTheme.ACCENT_GOLD);
        addStatRow(statsCard, "Favourite Items",
                String.valueOf(manager.getFavoriteItems().size()), new Color(80,220,140));

        statsCard.add(Box.createVerticalStrut(20));

        // Category breakdown
        JLabel breakTitle = AppTheme.label("Category Breakdown", AppTheme.fontBold(13), AppTheme.TEXT_MUTED);
        breakTitle.setAlignmentX(LEFT_ALIGNMENT);
        statsCard.add(breakTitle);
        statsCard.add(Box.createVerticalStrut(10));

        Map<String, Integer> catStats = manager.getCategoryStats();
        int total = manager.getTotalItems();
        for (Map.Entry<String, Integer> e : catStats.entrySet()) {
            if (e.getValue() == 0) continue;
            statsCard.add(buildProgressRow(e.getKey(), e.getValue(), total));
            statsCard.add(Box.createVerticalStrut(8));
        }

        col.add(statsCard);
        col.add(Box.createVerticalStrut(16));

        // Style tips card
        JPanel tipsCard = AppTheme.roundedPanel(new Color(35,20,60), 20);
        tipsCard.setLayout(new BoxLayout(tipsCard, BoxLayout.Y_AXIS));
        tipsCard.setBorder(AppTheme.padding(18, 20));

        JLabel tipsTitle = AppTheme.label("✨  Style Mantra", AppTheme.fontBold(15), AppTheme.ACCENT_GOLD);
        tipsTitle.setAlignmentX(LEFT_ALIGNMENT);
        tipsCard.add(tipsTitle);
        tipsCard.add(Box.createVerticalStrut(10));

        String[] tips = {
            "\"Fashion is the armor to survive the reality of everyday life.\"",
            "Dress for the version of yourself you're becoming.",
            "Confidence is the best outfit. Own it.",
            "Style is a way to say who you are without speaking."
        };
        java.util.Random rnd = new java.util.Random();
        JLabel tipLbl = new JLabel("<html><i>" + tips[rnd.nextInt(tips.length)] + "</i></html>");
        tipLbl.setFont(AppTheme.fontItalic(13));
        tipLbl.setForeground(AppTheme.TEXT_MUTED);
        tipLbl.setAlignmentX(LEFT_ALIGNMENT);
        tipsCard.add(tipLbl);

        col.add(tipsCard);
        col.add(Box.createVerticalGlue());

        return col;
    }

    private void addStatRow(JPanel p, String label, String value, Color color) {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setBorder(AppTheme.padding(6,10,6,10));
        row.setBackground(AppTheme.BG_CARD2);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));

        JLabel lbl = AppTheme.label(label, AppTheme.fontPlain(13), AppTheme.TEXT_MUTED);
        JLabel val = AppTheme.label(value, AppTheme.fontBold(20), color);
        row.add(lbl, BorderLayout.WEST);
        row.add(val, BorderLayout.EAST);
        row.setAlignmentX(LEFT_ALIGNMENT);

        JPanel wrapper = AppTheme.roundedPanel(AppTheme.BG_CARD2, 10);
        wrapper.setLayout(new BorderLayout());
        wrapper.add(row);
        wrapper.setAlignmentX(LEFT_ALIGNMENT);
        wrapper.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        p.add(wrapper);
        p.add(Box.createVerticalStrut(8));
    }

    private JPanel buildProgressRow(String label, int value, int total) {
        JPanel row = new JPanel(new BorderLayout(8, 2));
        row.setOpaque(false);
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));

        JLabel lbl = AppTheme.label(label, AppTheme.fontPlain(11), AppTheme.TEXT_MUTED);
        lbl.setPreferredSize(new Dimension(100, 16));
        JLabel cnt = AppTheme.label(String.valueOf(value), AppTheme.fontBold(11), AppTheme.ACCENT_PINK);
        cnt.setPreferredSize(new Dimension(24, 16));

        float pct = total == 0 ? 0 : (float) value / total;
        JPanel bar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(AppTheme.BG_CARD2);
                g2.fillRoundRect(0,2,getWidth(),10,6,6);
                GradientPaint gp = new GradientPaint(0,0,AppTheme.ACCENT_PURPLE,(int)(getWidth()*pct),0,AppTheme.ACCENT_PINK);
                g2.setPaint(gp);
                g2.fillRoundRect(0,2,(int)(getWidth()*pct),10,6,6);
            }
        };
        bar.setOpaque(false);
        bar.setPreferredSize(new Dimension(0, 14));

        row.add(lbl, BorderLayout.WEST);
        row.add(bar, BorderLayout.CENTER);
        row.add(cnt, BorderLayout.EAST);
        return row;
    }

    private void saveProfile() {
        UserProfile profile = manager.getUserProfile();
        profile.setFullName(nameField.getText().trim());
        profile.setBodyType((UserProfile.BodyType) bodyTypeCB.getSelectedItem());
        profile.setPreferredSeason((ClothingItem.Season) seasonCB.getSelectedItem());
        JOptionPane.showMessageDialog(this,"✨ Profile saved successfully!", "Saved", JOptionPane.INFORMATION_MESSAGE);
    }
}
