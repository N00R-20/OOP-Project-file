package fashion.util;

import fashion.model.ClothingItem;
import fashion.model.ClothingItem.Category;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Loads real fashion images from Unsplash for clothing items.
 * Uses item name keywords to pick the best matching image URL.
 * Falls back to a styled placeholder if loading fails.
 */
public class ImageLoader {

    private static final ExecutorService POOL = Executors.newFixedThreadPool(4);
    private static final Map<String, BufferedImage> CACHE = new HashMap<>();

    // ── Curated Unsplash image map keyed by item name (lowercase) ─────────────
    // Each URL is a direct Unsplash image resized to ~400x500
    private static final Map<String, String> IMAGE_URLS = new HashMap<String, String>() {{
        // TOPS
        put("silk blouse",        "https://images.unsplash.com/photo-1564257631407-4deb1f99d992?w=400&h=500&fit=crop");
        put("graphic tee",        "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=500&fit=crop");
        put("cashmere sweater",   "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=400&h=500&fit=crop");
        put("crop tank",          "https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=400&h=500&fit=crop");
        put("oxford shirt",       "https://images.unsplash.com/photo-1603252109303-2751441dd157?w=400&h=500&fit=crop");
        put("floral blouse",      "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=400&h=500&fit=crop");
        put("turtleneck",         "https://images.unsplash.com/photo-1608234808654-2a8875faa7fd?w=400&h=500&fit=crop");
        put("sports bra",         "https://images.unsplash.com/photo-1518459031867-a89b944bffe4?w=400&h=500&fit=crop");
        put("band tee",           "https://images.unsplash.com/photo-1503342452485-86b5b7491f00?w=400&h=500&fit=crop");
        put("lace cami",          "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=400&h=500&fit=crop");

        // BOTTOMS
        put("tailored trousers",  "https://images.unsplash.com/photo-1594938298603-c8148c4b4571?w=400&h=500&fit=crop");
        put("mom jeans",          "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=400&h=500&fit=crop");
        put("mini skirt",         "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=400&h=500&fit=crop");
        put("maxi skirt",         "https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=400&h=500&fit=crop");
        put("pleated skirt",      "https://images.unsplash.com/photo-1577900232427-18219b9166a0?w=400&h=500&fit=crop");
        put("joggers",            "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?w=400&h=500&fit=crop");
        put("cargo pants",        "https://images.unsplash.com/photo-1553267751-1c148a7280a1?w=400&h=500&fit=crop");
        put("leather trousers",   "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=400&h=500&fit=crop");

        // DRESSES
        put("wrap dress",         "https://images.unsplash.com/photo-1568252542512-9fe8fe9c87bb?w=400&h=500&fit=crop");
        put("lbd",                "https://images.unsplash.com/photo-1562137369-1a1a0bc66744?w=400&h=500&fit=crop");
        put("sundress",           "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=400&h=500&fit=crop");
        put("bodycon dress",      "https://images.unsplash.com/photo-1612336307429-8a898d10e223?w=400&h=500&fit=crop");
        put("shirt dress",        "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=500&fit=crop");

        // OUTERWEAR
        put("trench coat",        "https://images.unsplash.com/photo-1548369937-47519962c11a?w=400&h=500&fit=crop");
        put("denim jacket",       "https://images.unsplash.com/photo-1551537482-f2075a1d41f2?w=400&h=500&fit=crop");
        put("puffer jacket",      "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=400&h=500&fit=crop");
        put("blazer",             "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=500&fit=crop");
        put("leather jacket",     "https://images.unsplash.com/photo-1520975916090-3105956dac38?w=400&h=500&fit=crop");
        put("kimono",             "https://images.unsplash.com/photo-1553361371-9b22f78e8b1d?w=400&h=500&fit=crop");

        // SHOES
        put("stiletto heels",     "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=400&h=500&fit=crop");
        put("white sneakers",     "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=500&fit=crop");
        put("chelsea boots",      "https://images.unsplash.com/photo-1605812860427-4024433a70fd?w=400&h=500&fit=crop");
        put("strappy sandals",    "https://images.unsplash.com/photo-1515347619252-60a4bf4fff4f?w=400&h=500&fit=crop");
        put("running shoes",      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=500&fit=crop");
        put("loafers",            "https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=400&h=500&fit=crop");
        put("platform boots",     "https://images.unsplash.com/photo-1608256246200-535a63d58ebe?w=400&h=500&fit=crop");
        put("espadrilles",        "https://images.unsplash.com/photo-1562183241-b937e95585b6?w=400&h=500&fit=crop");

        // ACCESSORIES
        put("pearl necklace",     "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=500&fit=crop");
        put("silk scarf",         "https://images.unsplash.com/photo-1601924994987-69e26d50dc26?w=400&h=500&fit=crop");
        put("bucket hat",         "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?w=400&h=500&fit=crop");
        put("beret",              "https://images.unsplash.com/photo-1529958030586-3aae4ca485ff?w=400&h=500&fit=crop");
        put("gold hoops",         "https://images.unsplash.com/photo-1573408301185-9519f94815b1?w=400&h=500&fit=crop");
        put("sunglasses",         "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=400&h=500&fit=crop");
        put("beaded bracelet",    "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=400&h=500&fit=crop");

        // BAGS
        put("tote bag",           "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=400&h=500&fit=crop");
        put("mini crossbody",     "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400&h=500&fit=crop");
        put("backpack",           "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=500&fit=crop");
        put("clutch",             "https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?w=400&h=500&fit=crop");
        put("belt bag",           "https://images.unsplash.com/photo-1594938474506-2cf87f8b29cb?w=400&h=500&fit=crop");
        put("woven bag",          "https://images.unsplash.com/photo-1601924994987-69e26d50dc26?w=400&h=500&fit=crop");
    }};

    // ── Category fallback images ───────────────────────────────────────────────
    private static final Map<Category, String> CATEGORY_FALLBACKS = new HashMap<Category, String>() {{
        put(Category.TOP,        "https://images.unsplash.com/photo-1562157873-818bc0726f68?w=400&h=500&fit=crop");
        put(Category.BOTTOM,     "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=400&h=500&fit=crop");
        put(Category.DRESS,      "https://images.unsplash.com/photo-1568252542512-9fe8fe9c87bb?w=400&h=500&fit=crop");
        put(Category.OUTERWEAR,  "https://images.unsplash.com/photo-1548369937-47519962c11a?w=400&h=500&fit=crop");
        put(Category.SHOES,      "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=400&h=500&fit=crop");
        put(Category.ACCESSORIES,"https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=500&fit=crop");
        put(Category.BAG,        "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400&h=500&fit=crop");
    }};

    /**
     * Synchronously loads and returns a scaled ImageIcon.
     * Returns a stylish placeholder if the image cannot be loaded.
     */
    public static ImageIcon loadScaled(String itemName, Category category, int w, int h) {
        String key = (itemName + "_" + w + "x" + h).toLowerCase();
        if (CACHE.containsKey(key)) {
            return new ImageIcon(CACHE.get(key));
        }

        String url = IMAGE_URLS.getOrDefault(itemName.toLowerCase(),
                CATEGORY_FALLBACKS.getOrDefault(category,
                        "https://images.unsplash.com/photo-1445205170230-053b83016050?w=400&h=500&fit=crop"));
        try {
            BufferedImage raw = ImageIO.read(new URL(url));
            if (raw != null) {
                BufferedImage scaled = toScaled(raw, w, h);
                CACHE.put(key, scaled);
                return new ImageIcon(scaled);
            }
        } catch (Exception ignored) {}

        // Fallback: coloured placeholder
        return makePlaceholderPublic(itemName, category, w, h);
    }

    /**
     * Async version – calls callback on EDT when ready.
     */
    public static void loadAsync(String itemName, Category category, int w, int h,
                                  java.util.function.Consumer<ImageIcon> callback) {
        String key = (itemName + "_" + w + "x" + h).toLowerCase();
        if (CACHE.containsKey(key)) {
            callback.accept(new ImageIcon(CACHE.get(key)));
            return;
        }
        callback.accept(makePlaceholderPublic(itemName, category, w, h)); // show placeholder immediately
        POOL.submit(() -> {
            ImageIcon icon = loadScaled(itemName, category, w, h);
            SwingUtilities.invokeLater(() -> callback.accept(icon));
        });
    }

    private static BufferedImage toScaled(BufferedImage src, int w, int h) {
        // Crop to aspect ratio first, then scale
        int srcW = src.getWidth(), srcH = src.getHeight();
        double targetRatio = (double) w / h;
        double srcRatio = (double) srcW / srcH;
        int cropW = srcW, cropH = srcH, cropX = 0, cropY = 0;
        if (srcRatio > targetRatio) {
            cropW = (int)(srcH * targetRatio);
            cropX = (srcW - cropW) / 2;
        } else {
            cropH = (int)(srcW / targetRatio);
            cropY = (srcH - cropH) / 5; // slightly above center looks better for fashion
        }
        BufferedImage cropped = src.getSubimage(cropX, cropY, cropW, cropH);
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = out.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.drawImage(cropped, 0, 0, w, h, null);
        g2.dispose();
        return out;
    }

    public static ImageIcon makePlaceholderPublic(String name, Category cat, int w, int h) {
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Gradient background
        Color c1 = AppTheme.ACCENT_PURPLE, c2 = AppTheme.ACCENT_PINK;
        g2.setPaint(new GradientPaint(0, 0, new Color(c1.getRed(), c1.getGreen(), c1.getBlue(), 180),
                w, h, new Color(c2.getRed(), c2.getGreen(), c2.getBlue(), 180)));
        g2.fillRoundRect(0, 0, w, h, 12, 12);

        // Category emoji text
        String em = emojiFor(cat);
        g2.setFont(new Font("Segoe UI Emoji", Font.PLAIN, Math.min(w, h) / 3));
        FontMetrics fm = g2.getFontMetrics();
        int ex = (w - fm.stringWidth(em)) / 2;
        int ey = h / 2;
        g2.setColor(new Color(255, 255, 255, 200));
        g2.drawString(em, ex, ey);

        // Name label
        g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
        fm = g2.getFontMetrics();
        String label = name.length() > 18 ? name.substring(0, 16) + "…" : name;
        g2.setColor(Color.WHITE);
        g2.drawString(label, (w - fm.stringWidth(label)) / 2, h - 12);

        g2.dispose();
        return new ImageIcon(img);
    }

    private static String emojiFor(Category cat) {
        switch (cat) {
            case TOP: return "👕"; case BOTTOM: return "👖"; case DRESS: return "👗";
            case OUTERWEAR: return "🧥"; case SHOES: return "👠"; case ACCESSORIES: return "💍";
            case BAG: return "👜"; default: return "✨";
        }
    }

    public static void shutdown() { POOL.shutdown(); }
}
