package fashion.util;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Centralised theme & factory helpers for a consistent luxury UI.
 */
public class AppTheme {

    // ── Palette ──────────────────────────────────────────────────────────────
    public static final Color BG_DARK       = new Color(14, 12, 20);
    public static final Color BG_CARD       = new Color(26, 22, 38);
    public static final Color BG_CARD2      = new Color(35, 30, 52);
    public static final Color ACCENT_PINK   = new Color(255, 107, 157);
    public static final Color ACCENT_PURPLE = new Color(167, 104, 255);
    public static final Color ACCENT_GOLD   = new Color(255, 200, 100);
    public static final Color TEXT_WHITE    = new Color(245, 240, 255);
    public static final Color TEXT_MUTED    = new Color(160, 145, 190);
    public static final Color TEXT_DIM      = new Color(100, 90, 130);
    public static final Color SUCCESS       = new Color(80, 220, 140);
    public static final Color DANGER        = new Color(255, 80, 100);

    // ── Fonts ─────────────────────────────────────────────────────────────────
    public static Font fontBold(float size)   { return new Font("Segoe UI", Font.BOLD, (int)size); }
    public static Font fontPlain(float size)  { return new Font("Segoe UI", Font.PLAIN, (int)size); }
    public static Font fontItalic(float size) { return new Font("Segoe UI", Font.ITALIC, (int)size); }

    // ── Borders ───────────────────────────────────────────────────────────────
    public static Border padding(int v, int h) { return new EmptyBorder(v, h, v, h); }
    public static Border padding(int t, int l, int b, int r) { return new EmptyBorder(t,l,b,r); }

    // ── Gradient panel helper ─────────────────────────────────────────────────
    public static JPanel gradientPanel(Color c1, Color c2, boolean vertical) {
        return new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = vertical
                        ? new GradientPaint(0,0,c1,0,getHeight(),c2)
                        : new GradientPaint(0,0,c1,getWidth(),0,c2);
                g2.setPaint(gp);
                g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
    }

    // ── Rounded panel ─────────────────────────────────────────────────────────
    public static JPanel roundedPanel(Color bg, int radius) {
        return new JPanel() {
            { setOpaque(false); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fill(new RoundRectangle2D.Float(0,0,getWidth(),getHeight(),radius,radius));
                super.paintComponent(g);
            }
        };
    }

    // ── Custom button ─────────────────────────────────────────────────────────
    public static JButton accentButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color hover = bg.brighter();
                g2.setColor(getModel().isRollover() ? hover : bg);
                g2.fill(new RoundRectangle2D.Float(0,0,getWidth(),getHeight(),16,16));
                super.paintComponent(g);
            }
        };
        btn.setFont(fontBold(13));
        btn.setForeground(fg);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(padding(10, 22));
        return btn;
    }

    public static JButton ghostButton(String text) {
        JButton btn = accentButton(text, new Color(50,40,75), TEXT_WHITE);
        return btn;
    }

    // ── Styled label ──────────────────────────────────────────────────────────
    public static JLabel label(String text, Font font, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font);
        l.setForeground(color);
        return l;
    }

    // ── Styled text field ─────────────────────────────────────────────────────
    public static JTextField styledField(int cols) {
        JTextField f = new JTextField(cols);
        f.setFont(fontPlain(13));
        f.setBackground(BG_CARD2);
        f.setForeground(TEXT_WHITE);
        f.setCaretColor(ACCENT_PINK);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(80,60,120), 1, true),
                new EmptyBorder(8,12,8,12)));
        return f;
    }

    public static JTextArea styledArea(int rows, int cols) {
        JTextArea ta = new JTextArea(rows, cols);
        ta.setFont(fontPlain(13));
        ta.setBackground(BG_CARD2);
        ta.setForeground(TEXT_WHITE);
        ta.setCaretColor(ACCENT_PINK);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setBorder(new EmptyBorder(8,12,8,12));
        return ta;
    }

    // ── Styled combo ──────────────────────────────────────────────────────────
    public static <T> JComboBox<T> styledCombo(T[] items) {
        JComboBox<T> cb = new JComboBox<>(items);
        cb.setFont(fontPlain(13));
        cb.setBackground(BG_CARD2);
        cb.setForeground(TEXT_WHITE);
        cb.setBorder(BorderFactory.createLineBorder(new Color(80,60,120),1,true));
        cb.setFocusable(false);
        return cb;
    }

    // ── Setup global UI defaults ──────────────────────────────────────────────
    public static void applyGlobalDefaults() {
        UIManager.put("Panel.background", BG_DARK);
        UIManager.put("Label.foreground", TEXT_WHITE);
        UIManager.put("ToolTip.background", BG_CARD2);
        UIManager.put("ToolTip.foreground", TEXT_WHITE);
        UIManager.put("OptionPane.background", BG_CARD);
        UIManager.put("OptionPane.messageForeground", TEXT_WHITE);
        UIManager.put("Button.background", ACCENT_PINK);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("TextField.background", BG_CARD2);
        UIManager.put("TextField.foreground", TEXT_WHITE);
        UIManager.put("TextArea.background", BG_CARD2);
        UIManager.put("TextArea.foreground", TEXT_WHITE);
        UIManager.put("ComboBox.background", BG_CARD2);
        UIManager.put("ComboBox.foreground", TEXT_WHITE);
        UIManager.put("List.background", BG_CARD);
        UIManager.put("List.foreground", TEXT_WHITE);
        UIManager.put("List.selectionBackground", ACCENT_PURPLE);
        UIManager.put("List.selectionForeground", Color.WHITE);
        UIManager.put("ScrollBar.background", BG_DARK);
        UIManager.put("ScrollBar.thumb", new Color(80,60,120));
        UIManager.put("ScrollBar.track", BG_DARK);
        UIManager.put("ScrollPane.background", BG_DARK);
        UIManager.put("Table.background", BG_CARD);
        UIManager.put("Table.foreground", TEXT_WHITE);
        UIManager.put("Table.gridColor", BG_CARD2);
        UIManager.put("TableHeader.background", BG_CARD2);
        UIManager.put("TableHeader.foreground", ACCENT_PINK);
    }

    // ── Color swatch helper ───────────────────────────────────────────────────
    public static Color colorForName(String name) {
        if (name == null) return Color.LIGHT_GRAY;
        switch (name.toLowerCase()) {
            case "black": return new Color(30,30,30);
            case "white": case "ivory": case "cream": case "champagne": return new Color(240,235,220);
            case "red": case "scarlet": return new Color(220,50,50);
            case "navy": case "navy blue": return new Color(30,50,120);
            case "blue": case "light blue": return new Color(80,130,200);
            case "pink": case "blush": case "dusty rose": return new Color(240,180,190);
            case "camel": case "tan": case "natural": return new Color(200,165,120);
            case "olive": case "forest green": return new Color(100,130,60);
            case "gold": case "metallic silver": return new Color(220,185,80);
            case "coral": return new Color(240,120,90);
            case "yellow": return new Color(245,210,50);
            case "grey": case "charcoal": case "gray": return new Color(130,130,140);
            case "terracotta": return new Color(200,100,70);
            case "brown": return new Color(140,90,50);
            case "multicolor": case "floral": case "stripe": case "printed": case "mixed":
                return new Color(160,100,200);
            default: return new Color(100,80,160);
        }
    }
}
