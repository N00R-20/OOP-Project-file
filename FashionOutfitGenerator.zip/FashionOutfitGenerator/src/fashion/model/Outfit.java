package fashion.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a complete outfit composed of multiple clothing items.
 */
public class Outfit implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;
    private String name;
    private List<ClothingItem> items;
    private ClothingItem.Season season;
    private ClothingItem.Style style;
    private String occasion;
    private String notes;
    private LocalDate dateCreated;
    private boolean isFavorite;
    private int rating; // 1-5

    public Outfit(String id, String name, ClothingItem.Season season,
                  ClothingItem.Style style, String occasion) {
        this.id = id;
        this.name = name;
        this.season = season;
        this.style = style;
        this.occasion = occasion;
        this.items = new ArrayList<>();
        this.dateCreated = LocalDate.now();
        this.isFavorite = false;
        this.rating = 0;
        this.notes = "";
    }

    public void addItem(ClothingItem item) {
        if (item != null && !items.contains(item)) {
            items.add(item);
        }
    }

    public void removeItem(ClothingItem item) {
        items.remove(item);
    }

    public boolean hasCategory(ClothingItem.Category category) {
        return items.stream().anyMatch(i -> i.getCategory() == category);
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public List<ClothingItem> getItems() { return new ArrayList<>(items); }
    public ClothingItem.Season getSeason() { return season; }
    public ClothingItem.Style getStyle() { return style; }
    public String getOccasion() { return occasion; }
    public String getNotes() { return notes; }
    public LocalDate getDateCreated() { return dateCreated; }
    public boolean isFavorite() { return isFavorite; }
    public int getRating() { return rating; }

    // Setters
    public void setName(String name) { this.name = name; }
    public void setSeason(ClothingItem.Season season) { this.season = season; }
    public void setStyle(ClothingItem.Style style) { this.style = style; }
    public void setOccasion(String occasion) { this.occasion = occasion; }
    public void setNotes(String notes) { this.notes = notes; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }
    public void setRating(int rating) {
        if (rating >= 0 && rating <= 5) this.rating = rating;
    }

    public String getSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("Outfit: ").append(name).append("\n");
        sb.append("Style: ").append(style).append(" | Season: ").append(season).append("\n");
        sb.append("Occasion: ").append(occasion).append("\n");
        sb.append("Items (").append(items.size()).append("):\n");
        for (ClothingItem item : items) {
            sb.append("  • ").append(item.getName()).append(" - ").append(item.getColor()).append("\n");
        }
        if (!notes.isEmpty()) sb.append("Notes: ").append(notes);
        return sb.toString();
    }

    @Override
    public String toString() {
        return name + " (" + style + ", " + season + ")";
    }
}
