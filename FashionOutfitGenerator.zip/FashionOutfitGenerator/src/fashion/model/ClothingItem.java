package fashion.model;

import java.io.Serializable;

/**
 * Represents a single clothing item in the wardrobe.
 */
public class ClothingItem implements Serializable {

    private static final long serialVersionUID = 1L;

    public enum Category {
        TOP("Tops"), BOTTOM("Bottoms"), DRESS("Dresses"), OUTERWEAR("Outerwear"),
        SHOES("Shoes"), ACCESSORIES("Accessories"), BAG("Bags");

        private final String displayName;
        Category(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
        @Override public String toString() { return displayName; }
    }

    public enum Season {
        SPRING("Spring"), SUMMER("Summer"), AUTUMN("Autumn"), WINTER("Winter"), ALL_SEASON("All Season");
        private final String displayName;
        Season(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
        @Override public String toString() { return displayName; }
    }

    public enum Style {
        CASUAL("Casual"), FORMAL("Formal"), SPORTY("Sporty"),
        ELEGANT("Elegant"), BOHEMIAN("Bohemian"), STREETWEAR("Streetwear"), VINTAGE("Vintage");
        private final String displayName;
        Style(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
        @Override public String toString() { return displayName; }
    }

    private String id;
    private String name;
    private String brand;
    private String color;
    private Category category;
    private Season season;
    private Style style;
    private String description;
    private boolean isFavorite;

    public ClothingItem(String id, String name, String brand, String color,
                        Category category, Season season, Style style, String description) {
        this.id = id;
        this.name = name;
        this.brand = brand;
        this.color = color;
        this.category = category;
        this.season = season;
        this.style = style;
        this.description = description;
        this.isFavorite = false;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getBrand() { return brand; }
    public String getColor() { return color; }
    public Category getCategory() { return category; }
    public Season getSeason() { return season; }
    public Style getStyle() { return style; }
    public String getDescription() { return description; }
    public boolean isFavorite() { return isFavorite; }

    // Setters
    public void setName(String name) { this.name = name; }
    public void setBrand(String brand) { this.brand = brand; }
    public void setColor(String color) { this.color = color; }
    public void setCategory(Category category) { this.category = category; }
    public void setSeason(Season season) { this.season = season; }
    public void setStyle(Style style) { this.style = style; }
    public void setDescription(String description) { this.description = description; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }

    @Override
    public String toString() {
        return name + " (" + brand + ") - " + color;
    }
}
