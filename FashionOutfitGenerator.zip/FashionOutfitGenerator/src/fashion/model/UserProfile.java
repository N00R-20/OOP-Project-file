package fashion.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a user profile with personal style preferences.
 */
public class UserProfile implements Serializable {

    private static final long serialVersionUID = 1L;

    public enum BodyType {
        PETITE("Petite"), SLIM("Slim"), AVERAGE("Average"),
        ATHLETIC("Athletic"), CURVY("Curvy"), PLUS_SIZE("Plus Size");
        private final String displayName;
        BodyType(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
        @Override public String toString() { return displayName; }
    }

    private String username;
    private String fullName;
    private BodyType bodyType;
    private List<ClothingItem.Style> preferredStyles;
    private List<String> favoriteColors;
    private ClothingItem.Season preferredSeason;
    private String profileEmoji;

    public UserProfile(String username, String fullName) {
        this.username = username;
        this.fullName = fullName;
        this.bodyType = BodyType.AVERAGE;
        this.preferredStyles = new ArrayList<>();
        this.favoriteColors = new ArrayList<>();
        this.preferredSeason = ClothingItem.Season.ALL_SEASON;
        this.profileEmoji = "👗";
    }

    // Getters
    public String getUsername() { return username; }
    public String getFullName() { return fullName; }
    public BodyType getBodyType() { return bodyType; }
    public List<ClothingItem.Style> getPreferredStyles() { return preferredStyles; }
    public List<String> getFavoriteColors() { return favoriteColors; }
    public ClothingItem.Season getPreferredSeason() { return preferredSeason; }
    public String getProfileEmoji() { return profileEmoji; }

    // Setters
    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setBodyType(BodyType bodyType) { this.bodyType = bodyType; }
    public void setPreferredSeason(ClothingItem.Season preferredSeason) { this.preferredSeason = preferredSeason; }
    public void setProfileEmoji(String profileEmoji) { this.profileEmoji = profileEmoji; }

    public void addPreferredStyle(ClothingItem.Style style) {
        if (!preferredStyles.contains(style)) preferredStyles.add(style);
    }
    public void addFavoriteColor(String color) {
        if (!favoriteColors.contains(color)) favoriteColors.add(color);
    }

    @Override
    public String toString() { return fullName + " (@" + username + ")"; }
}
