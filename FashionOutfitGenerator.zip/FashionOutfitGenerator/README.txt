╔══════════════════════════════════════════════════════════════╗
║         FASHION OUTFIT GENERATOR  –  OOP Java Project       ║
╚══════════════════════════════════════════════════════════════╝

HOW TO OPEN IN ECLIPSE
──────────────────────
1. Open Eclipse IDE
2. File → Import → General → Existing Projects into Workspace
3. Browse to the extracted "FashionOutfitGenerator" folder → Finish
4. Right-click Main.java (src/fashion/) → Run As → Java Application

NOTE ON IMAGES
──────────────
The app loads real fashion photos from Unsplash (internet required).
Each clothing card shows a real photo that matches the item name.
If offline, beautiful gradient placeholders are shown automatically.

FEATURES
────────
✨ Outfit Generator  – generates complete looks with real item photos
👗 Wardrobe Manager – 50 preloaded items shown as photo cards; add/remove/search
💾 Saved Outfits    – card gallery of all your saved looks
👤 Profile          – body type, preferred season, wardrobe stats

OOP CONCEPTS
────────────
Encapsulation  – private fields + getters/setters (ClothingItem, Outfit, UserProfile)
Abstraction    – WardrobeManager hides all data logic
Inheritance    – custom Swing components extend JPanel, JButton, etc.
Polymorphism   – paintComponent overrides, ListCellRenderer, ActionListener
Singleton      – WardrobeManager.getInstance()
Enums          – Category, Season, Style, BodyType
Collections    – ArrayList, List, Map, Streams

PACKAGE STRUCTURE
─────────────────
src/fashion/
  Main.java
  model/  ClothingItem  Outfit  UserProfile
  data/   WardrobeManager  (singleton, 50 sample items)
  ui/     MainWindow  GeneratorPanel  WardrobePanel
          SavedOutfitsPanel  ProfilePanel  SplashScreen
  util/   AppTheme  ImageLoader

REQUIREMENTS
────────────
Java 11+  |  No external JARs  |  Internet for live photos (optional)
